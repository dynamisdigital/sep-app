# Manifesto de Assets — Mockup_07 V2 margem segura corrigida

Destino sugerido no projeto:

C:\Pastas\PROJETOS\Projeto Dynamis SEP\sep-app 16062026\image\sep_mockup_07_assets

Observação: os ícones foram reextraídos do mockup original com recorte ampliado, centralização e margem transparente segura. Para ícones circulares/HUD, o recorte preserva a circunferência inteira antes de aplicar a folga equivalente ao padrão de aproximadamente 2 mm digitais.

| Categoria | Arquivo | Caminho público sugerido | Tamanho | Observação |
|---|---|---|---|---|
| logos | logo_sep_header_completo.png | /image/sep_mockup_07_assets/logos/logo_sep_header_completo.png | 160x58 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| logos | logo_sep_simbolo_header.png | /image/sep_mockup_07_assets/logos/logo_sep_simbolo_header.png | 79x79 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| logos | logo_sep_wordmark_header.png | /image/sep_mockup_07_assets/logos/logo_sep_wordmark_header.png | 105x50 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| logos | logo_sep_footer_completo.png | /image/sep_mockup_07_assets/logos/logo_sep_footer_completo.png | 160x58 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| logos | logo_sep_simbolo_footer.png | /image/sep_mockup_07_assets/logos/logo_sep_simbolo_footer.png | 70x70 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_dashboard.png | /image/sep_mockup_07_assets/icons/sidebar_dashboard.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_onboarding.png | /image/sep_mockup_07_assets/icons/sidebar_onboarding.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_credito.png | /image/sep_mockup_07_assets/icons/sidebar_credito.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_formalizacao.png | /image/sep_mockup_07_assets/icons/sidebar_formalizacao.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_cobranca.png | /image/sep_mockup_07_assets/icons/sidebar_cobranca.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_backoffice.png | /image/sep_mockup_07_assets/icons/sidebar_backoffice.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_pix.png | /image/sep_mockup_07_assets/icons/sidebar_pix.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_perfil.png | /image/sep_mockup_07_assets/icons/sidebar_perfil.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | sidebar_help.png | /image/sep_mockup_07_assets/icons/sidebar_help.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | topbar_ambiente_regulado_shield.png | /image/sep_mockup_07_assets/icons/topbar_ambiente_regulado_shield.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | topbar_horario_sistema.png | /image/sep_mockup_07_assets/icons/topbar_horario_sistema.png | 74x74 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | topbar_search.png | /image/sep_mockup_07_assets/icons/topbar_search.png | 76x76 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | topbar_bell_notification.png | /image/sep_mockup_07_assets/icons/topbar_bell_notification.png | 90x90 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | topbar_help.png | /image/sep_mockup_07_assets/icons/topbar_help.png | 77x77 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | topbar_avatar_d.png | /image/sep_mockup_07_assets/icons/topbar_avatar_d.png | 90x90 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | topbar_theme_sun.png | /image/sep_mockup_07_assets/icons/topbar_theme_sun.png | 79x79 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | back_to_onboarding_arrow.png | /image/sep_mockup_07_assets/icons/back_to_onboarding_arrow.png | 66x66 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | page_title_kyc_badge.png | /image/sep_mockup_07_assets/icons/page_title_kyc_badge.png | 76x48 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | step_identificacao_1_active.png | /image/sep_mockup_07_assets/icons/step_identificacao_1_active.png | 98x98 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | step_documentos_2.png | /image/sep_mockup_07_assets/icons/step_documentos_2.png | 98x98 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | step_verificacao_3.png | /image/sep_mockup_07_assets/icons/step_verificacao_3.png | 98x98 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | step_revisao_4.png | /image/sep_mockup_07_assets/icons/step_revisao_4.png | 98x98 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | card_dados_pessoais_icon.png | /image/sep_mockup_07_assets/icons/card_dados_pessoais_icon.png | 108x108 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | badge_ambiente_regulado_icon.png | /image/sep_mockup_07_assets/icons/badge_ambiente_regulado_icon.png | 84x84 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | input_cpf_document.png | /image/sep_mockup_07_assets/icons/input_cpf_document.png | 70x70 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | input_nome_usuario.png | /image/sep_mockup_07_assets/icons/input_nome_usuario.png | 70x70 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | input_data_calendario.png | /image/sep_mockup_07_assets/icons/input_data_calendario.png | 72x72 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | button_continuar_arrow.png | /image/sep_mockup_07_assets/icons/button_continuar_arrow.png | 66x66 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | footnote_lock.png | /image/sep_mockup_07_assets/icons/footnote_lock.png | 54x54 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | benefit_protecao_dados.png | /image/sep_mockup_07_assets/icons/benefit_protecao_dados.png | 106x106 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | benefit_ambiente_regulado.png | /image/sep_mockup_07_assets/icons/benefit_ambiente_regulado.png | 106x106 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | benefit_processo_seguro.png | /image/sep_mockup_07_assets/icons/benefit_processo_seguro.png | 106x106 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | benefit_100_digital.png | /image/sep_mockup_07_assets/icons/benefit_100_digital.png | 106x106 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | summary_kyc_badge.png | /image/sep_mockup_07_assets/icons/summary_kyc_badge.png | 94x65 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | summary_timeline_step_1.png | /image/sep_mockup_07_assets/icons/summary_timeline_step_1.png | 78x78 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | summary_timeline_step_2.png | /image/sep_mockup_07_assets/icons/summary_timeline_step_2.png | 78x78 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | summary_timeline_step_3.png | /image/sep_mockup_07_assets/icons/summary_timeline_step_3.png | 78x78 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | summary_timeline_step_4.png | /image/sep_mockup_07_assets/icons/summary_timeline_step_4.png | 78x78 | PNG transparente com badge/circunferência preservado por máscara circular e margem segura. |
| icons | info_kyc_icon.png | /image/sep_mockup_07_assets/icons/info_kyc_icon.png | 82x82 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | info_external_link.png | /image/sep_mockup_07_assets/icons/info_external_link.png | 63x63 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | help_chat_icon.png | /image/sep_mockup_07_assets/icons/help_chat_icon.png | 82x82 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| icons | help_button_arrow.png | /image/sep_mockup_07_assets/icons/help_button_arrow.png | 66x66 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| visuals | visual_dados_pessoais_profile_hud.png | /image/sep_mockup_07_assets/visuals/visual_dados_pessoais_profile_hud.png | 140x140 | PNG transparente, centralizado, recorte ampliado e margem segura após a circunferência/glow do elemento. |
| visuals | visual_secure_progress_glow.png | /image/sep_mockup_07_assets/visuals/visual_secure_progress_glow.png | 1102x80 | Fundo/linha do stepper para composição; não usar como substituto dos textos HTML. |
| visuals | visual_fundo_circuitos_main.png | /image/sep_mockup_07_assets/visuals/visual_fundo_circuitos_main.png | 640x210 | Fundo tecnológico com circuitos e pontos em transparência para composição. |
| visuals | visual_main_background_dots.png | /image/sep_mockup_07_assets/visuals/visual_main_background_dots.png | 520x540 | Pontos/circuitos de fundo para composição. |
| ui-groups | ui_topbar.png | /image/sep_mockup_07_assets/ui-groups/ui_topbar.png | 1448x75 | Topbar completa de referência visual. |
| ui-groups | ui_sidebar.png | /image/sep_mockup_07_assets/ui-groups/ui_sidebar.png | 249x930 | Sidebar completa de referência visual. |
| ui-groups | ui_footer.png | /image/sep_mockup_07_assets/ui-groups/ui_footer.png | 1448x86 | Footer completo de referência visual. |
| ui-groups | ui_progress_steps.png | /image/sep_mockup_07_assets/ui-groups/ui_progress_steps.png | 1102x80 | Stepper da jornada KYC. |
| ui-groups | ui_form_dados_pessoais_card.png | /image/sep_mockup_07_assets/ui-groups/ui_form_dados_pessoais_card.png | 732x510 | Card do formulário de dados pessoais. |
| ui-groups | ui_resumo_jornada_card.png | /image/sep_mockup_07_assets/ui-groups/ui_resumo_jornada_card.png | 345x351 | Card resumo da jornada. |
| ui-groups | ui_o_que_e_kyc_card.png | /image/sep_mockup_07_assets/ui-groups/ui_o_que_e_kyc_card.png | 344x159 | Card explicativo O que é KYC. |
| ui-groups | ui_precisa_ajuda_card.png | /image/sep_mockup_07_assets/ui-groups/ui_precisa_ajuda_card.png | 344x139 | Card de suporte/ajuda. |
| ui-groups | ui_benefits_strip.png | /image/sep_mockup_07_assets/ui-groups/ui_benefits_strip.png | 732x113 | Faixa de benefícios inferiores. |
| ui-groups | ui_back_to_onboarding_button.png | /image/sep_mockup_07_assets/ui-groups/ui_back_to_onboarding_button.png | 212x48 | Botão Voltar para Onboarding. |